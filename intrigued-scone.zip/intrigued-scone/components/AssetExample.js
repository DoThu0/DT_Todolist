import { Text, View, StyleSheet, Image } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
       Fullname: Do Anh Thu                
      </Text>
      <Text style={styles.paragraph}>
        Phone: 0813134072
      </Text>
      <Text style={styles.paragraph}>
        Student ID: 220501709
      </Text>
      <Text style={styles.paragraph}>
        Email: dothu1153@gmail.com
      </Text>
      <Text style={styles.paragraph}>
        Hobbies: music
      </Text>
      <Image style={styles.logo} source={require('../assets/hihi.jpg')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 128,
    width: 128,
  }
});
